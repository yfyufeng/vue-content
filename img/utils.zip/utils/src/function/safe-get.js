import isFunction from '@hui-pro/utils/src/test/is-function.js';

const safeGet = (object, key) => {
  if (key === 'constructor' && typeof isFunction(object[key])) {
    return;
  }

  if (key === '__proto__') {
    return;
  }

  return object[key];
};

export default safeGet;
