import regExp from './reg-exp.js';
export { regExp };
