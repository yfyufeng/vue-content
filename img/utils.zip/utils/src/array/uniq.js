const uniq = arr => {
  return Array.from(new Set(arr));
};

export default uniq;
