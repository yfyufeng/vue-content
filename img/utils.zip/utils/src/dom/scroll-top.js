import { scrollTop } from '@hui-pro/utils/src/dom/scroll.js';

export default scrollTop;
