import { getPageX } from '@hui-pro/utils/src/dom/get-page.js';

export default getPageX;
