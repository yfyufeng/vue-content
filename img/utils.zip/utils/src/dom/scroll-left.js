import { scrollLeft } from '@hui-pro/utils/src/dom/scroll.js';

export default scrollLeft;
