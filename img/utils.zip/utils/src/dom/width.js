import { width } from '@hui-pro/utils/src/dom/size.js';

export default width;
