import { height } from '@hui-pro/utils/src/dom/size.js';

export default height;
