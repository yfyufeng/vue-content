const removeNode = el => {
  el.parentNode.removeChild(el);
};

export default removeNode;
