import { getPageY } from '@hui-pro/utils/src/dom/get-page.js';

export default getPageY;
