const getNodeName = el => {
  return el.nodeName && el.nodeName.toLowerCase();
};

export default getNodeName;
