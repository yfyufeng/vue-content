const isNumber = val => typeof val === 'number';

export default isNumber;
