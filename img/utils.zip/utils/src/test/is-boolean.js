import type from '@hui-pro/utils/src/test/type.js';
const isBoolean = val => type(val) === 'Boolean';

export default isBoolean;
