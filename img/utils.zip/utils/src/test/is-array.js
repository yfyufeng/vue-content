import type from '@hui-pro/utils/src/test/type.js';
const isArray = val => type(val) === 'Array';

export default isArray;
