const isNull = val => val === null;

export default isNull;
