import type from '@hui-pro/utils/src/test/type.js';
const isMath = val => type(val) === 'Math';

export default isMath;
