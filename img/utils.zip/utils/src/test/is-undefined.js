const isUndefined = val => typeof val === 'undefined';

export default isUndefined;
