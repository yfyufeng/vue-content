import type from '@hui-pro/utils/src/test/type.js';
const isString = val => type(val) === 'String';

export default isString;
