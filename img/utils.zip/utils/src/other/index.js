import hideSensitiveText from './hide-sensitive-text.js';
import trimOnlySpace from './trim-only-space.js';
export { hideSensitiveText, trimOnlySpace };
