import deepClone from './deep-clone.js';
import merge from './merge.js';
export { deepClone, merge };
